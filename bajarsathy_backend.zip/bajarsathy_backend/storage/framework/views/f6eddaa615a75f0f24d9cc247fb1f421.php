

<?php $__env->startSection('title', 'Today\'s Prices'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
    <div class="bg-green-100 text-green-700 p-2 mb-4 rounded">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<table class="min-w-full bg-white border">
    <thead>
        <tr>
            <th class="border px-4 py-2">ID</th>
            <th class="border px-4 py-2">Product Name</th>
            <th class="border px-4 py-2">Unit</th>
            <th class="border px-4 py-2">Min Price</th>
            <th class="border px-4 py-2">Max Price</th>
            <th class="border px-4 py-2">Avg Price</th>
            <th class="border px-4 py-2">Product Image</th>
            <th class="border px-4 py-2">Update Image</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($price->id); ?></td>
                <td class="border px-4 py-2"><?php echo e($price->product_name); ?></td>
                <td class="border px-4 py-2"><?php echo e($price->unit); ?></td>
                <td class="border px-4 py-2"><?php echo e($price->min_price); ?></td>
                <td class="border px-4 py-2"><?php echo e($price->max_price); ?></td>
                <td class="border px-4 py-2"><?php echo e($price->avg_price); ?></td>
                <td class="border px-4 py-2">
                    <?php if($price->product_image): ?>
                        <img src="<?php echo e(asset('uploads/products/' . $price->product_image)); ?>" class="w-16 h-16 object-cover rounded">
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td class="border px-4 py-2">
                    <form action="<?php echo e(route('prices.updateImage', $price->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="file" name="product_image" class="border p-1 mb-1 w-full">
                        <button type="submit" class="bg-blue-600 text-white px-3 py-1 rounded w-full">
                            Update
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\OneDrive\Desktop\bajarsathy\bajarsathy_backend\resources\views/data.blade.php ENDPATH**/ ?>